INSERT INTO syssessiontypes VALUES (4104, 'Mobile App', 432000, now(), now());
