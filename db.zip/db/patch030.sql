ALTER TABLE `companies` 
ADD COLUMN `gst_registration_type` VARCHAR(32) NULL AFTER `gst_number`;

