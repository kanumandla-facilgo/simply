alter table `products` add column `cost` DECIMAL(10, 2) NULL AFTER `default_sell_qty` ;
