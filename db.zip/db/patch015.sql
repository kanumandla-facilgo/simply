ALTER TABLE `companies` 
ADD COLUMN `gst_number` VARCHAR(24) NULL AFTER `excise_number`;
