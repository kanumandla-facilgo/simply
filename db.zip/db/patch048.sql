ALTER TABLE `products` 
ADD COLUMN `default_sell_qty` DECIMAL(12,4) NULL AFTER `sysproducthsn_id`;
